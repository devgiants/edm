### 1.0.2 (-)

  * Added `DoctrineODMPhpcrAdapter`
  * Added endpoint to `SolariumAdapter`
  * Added $useOutputWalkers mode into the DoctrineORM adapter

### 1.0.1 (2013-09-23)

  * Added `TwitterBootstrap3View`
  * Made `getResultSet` public in the `SolariumAdapter`
  * Fixed the `last` method in the `DefaultView` to call the last method of the template
  * Added `currentPageOffsetStart` and `currentPageOffsetEnd` to `Pagerfanta`
  * Fixed the minimum number of pages to 1

### 1.0.0 (2013-04-24)

  * Initial release
