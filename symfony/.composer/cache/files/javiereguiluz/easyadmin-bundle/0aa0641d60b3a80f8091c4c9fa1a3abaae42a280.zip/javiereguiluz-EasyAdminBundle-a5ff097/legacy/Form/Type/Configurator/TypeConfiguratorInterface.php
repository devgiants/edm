<?php

namespace JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator;

@trigger_error('The '.__NAMESPACE__.'\TypeConfiguratorInterface interface is deprecated since version 1.16 and will be removed in 2.0. Use the EasyCorp\Bundle\EasyAdminBundle\Form\Type\Configurator\TypeConfiguratorInterface interface instead.', E_USER_DEPRECATED);

class_exists('EasyCorp\Bundle\EasyAdminBundle\Form\Type\Configurator\TypeConfiguratorInterface');

if (\false) {
    interface TypeConfiguratorInterface
    {
    }
}
