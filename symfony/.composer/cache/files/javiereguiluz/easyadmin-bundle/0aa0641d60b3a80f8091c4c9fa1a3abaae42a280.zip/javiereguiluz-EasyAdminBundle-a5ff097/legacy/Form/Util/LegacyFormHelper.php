<?php

namespace JavierEguiluz\Bundle\EasyAdminBundle\Form\Util;

@trigger_error('The '.__NAMESPACE__.'\LegacyFormHelper class is deprecated since version 1.16 and will be removed in 2.0. Use the EasyCorp\Bundle\EasyAdminBundle\Form\Util\LegacyFormHelper class instead.', E_USER_DEPRECATED);

class_exists('EasyCorp\Bundle\EasyAdminBundle\Form\Util\LegacyFormHelper');

if (\false) {
    final class LegacyFormHelper
    {
    }
}
