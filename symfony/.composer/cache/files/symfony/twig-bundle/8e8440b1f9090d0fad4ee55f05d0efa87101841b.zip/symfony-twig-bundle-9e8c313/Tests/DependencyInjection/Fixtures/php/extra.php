<?php

$container->loadFromExtension('twig', array(
     'paths' => array(
         'namespaced_path3' => 'namespace3',
      ),
));
